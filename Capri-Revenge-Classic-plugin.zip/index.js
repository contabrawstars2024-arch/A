({
  preInit({ themes }) {
    themes.registerGroup('capri', {
      name: 'Capri',
      description: 'Azul-marinho profundo com detalhes em ciano.'
    });

    themes.registerTheme('capri', 'ocean', {
      name: 'Capri Ocean',
      getColors: () => ({
        semantic: {
          dark: {
            BACKGROUND_BASE_LOWEST: '#071B2A',
            BACKGROUND_BASE_LOWER: '#0A2436',
            BACKGROUND_BASE: '#0D2C42',
            BACKGROUND_BASE_HIGH: '#10364D',
            BACKGROUND_SURFACE: '#0A2436',
            BACKGROUND_SURFACE_HOVER: '#12384D',
            TEXT_DEFAULT: '#D5EEF7',
            TEXT_MUTED: '#78AFC4',
            TEXT_LINK: '#52D8F2',
            HEADER_PRIMARY: '#E6F8FF',
            HEADER_SECONDARY: '#A8D8E8',
            INTERACTIVE_NORMAL: '#A8D8E8',
            INTERACTIVE_HOVER: '#E6F8FF',
            INTERACTIVE_ACTIVE: '#FFFFFF'
          },
          darker: {
            BACKGROUND_BASE_LOWEST: '#04131D',
            BACKGROUND_BASE_LOWER: '#071B2A',
            BACKGROUND_BASE: '#0A2436',
            BACKGROUND_BASE_HIGH: '#0D2C42',
            BACKGROUND_SURFACE: '#071B2A',
            BACKGROUND_SURFACE_HOVER: '#10364D',
            TEXT_DEFAULT: '#D5EEF7',
            TEXT_MUTED: '#78AFC4',
            TEXT_LINK: '#52D8F2',
            HEADER_PRIMARY: '#E6F8FF',
            HEADER_SECONDARY: '#A8D8E8',
            INTERACTIVE_NORMAL: '#A8D8E8',
            INTERACTIVE_HOVER: '#E6F8FF',
            INTERACTIVE_ACTIVE: '#FFFFFF'
          },
          midnight: {
            BACKGROUND_BASE_LOWEST: '#030D14',
            BACKGROUND_BASE_LOWER: '#04131D',
            BACKGROUND_BASE: '#071B2A',
            BACKGROUND_BASE_HIGH: '#0A2436',
            BACKGROUND_SURFACE: '#04131D',
            BACKGROUND_SURFACE_HOVER: '#0D2C42',
            TEXT_DEFAULT: '#D5EEF7',
            TEXT_MUTED: '#78AFC4',
            TEXT_LINK: '#52D8F2',
            HEADER_PRIMARY: '#E6F8FF',
            HEADER_SECONDARY: '#A8D8E8',
            INTERACTIVE_NORMAL: '#A8D8E8',
            INTERACTIVE_HOVER: '#E6F8FF',
            INTERACTIVE_ACTIVE: '#FFFFFF'
          }
        },
        raw: {
          BRAND_500: '#35C8E8',
          BRAND_600: '#168BAA',
          BRAND_700: '#11748F',
          PRIMARY_100: '#E6F8FF',
          PRIMARY_200: '#BFEAF5',
          PRIMARY_300: '#8DD9EA',
          PRIMARY_400: '#52D8F2',
          PRIMARY_500: '#35C8E8',
          PRIMARY_600: '#168BAA',
          PRIMARY_700: '#0D5B73',
          PRIMARY_800: '#0A3A4D',
          PRIMARY_900: '#071B2A'
        }
      })
    });
  }
})